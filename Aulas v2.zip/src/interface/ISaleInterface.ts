interface ISaleInterface {
    id?: string;
    userId: string;
    productId: string;
    clientID: string;
    quantity: string;
}

export { ISaleInterface }
