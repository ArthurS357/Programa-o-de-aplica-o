interface IProductInterface {
    id?: string;
    name: string;
    description?: string;
    price: string;
    categoryId: string;
}

export {IProductInterface}

