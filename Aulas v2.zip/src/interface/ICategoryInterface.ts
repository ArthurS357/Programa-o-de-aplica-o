interface ICategoryInterface {
    id?: string;
    name: string;
    description: string;
}

export {ICategoryInterface}
