interface ISaleInterface {
    id?: number;
    userId: string;
    productId: string;
    clientID: boolean;
    quantity: string;
}

export {ISaleInterface}

//já foi