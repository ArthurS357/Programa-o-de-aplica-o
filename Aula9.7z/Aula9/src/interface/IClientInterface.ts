interface IClientInterface {
    id?: number;
    name: string;
    description?: string;
    cpf: boolean;
    address: string;
    fone: string;
}

export {IClientInterface}

//feito