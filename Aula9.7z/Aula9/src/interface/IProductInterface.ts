interface IProductInterface {
    id?: number;
    name: string;
    description?: string;
    price: String;
    categoryId: String;
}

export {IProductInterface}

//já foi