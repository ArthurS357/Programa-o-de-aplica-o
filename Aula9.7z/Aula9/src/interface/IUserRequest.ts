interface IUserRequest {
    id?: number;
    name: string;
    email: string;
    admin?: boolean;
    password: string;
}

export {IUserRequest}

//já foi