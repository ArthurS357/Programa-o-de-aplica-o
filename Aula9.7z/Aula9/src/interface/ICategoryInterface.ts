interface ICategoryInterface {
    id?: number;
    name: string;
    description: string;
}

export {ICategoryInterface}

//feito