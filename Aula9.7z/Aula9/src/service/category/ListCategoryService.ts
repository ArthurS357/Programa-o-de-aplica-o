class ListCategoryService {
    async execute() {
        const category = [ 
            {          
                id:1,
                name: "Sofá",
                description:"grande"             
          }   
        ];
      return category
    }
  }
  export { ListCategoryService };
  