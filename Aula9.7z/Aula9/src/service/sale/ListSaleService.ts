class ListSaleService {
    async execute() {
        const sales = [ 
            {          
                id:1,
                name: "arroz",
                description:"branco",
                price: "92831892",
                categoryId: 19              
          }   
        ];
      return sales
    }
  }
  export { ListSaleService };
  